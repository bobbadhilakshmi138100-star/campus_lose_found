package com.example.ui.dialogs

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Handshake
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Sms
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.PostType
import com.example.ui.theme.MuBorder
import com.example.ui.theme.MuCrimson
import com.example.ui.theme.MuNavy
import com.example.ui.theme.MuSurface
import com.example.ui.theme.MuTextMain
import com.example.ui.theme.MuTextMuted

@Composable
fun ReportItemDialog(
    onDismiss: () -> Unit,
    onSubmit: (PostType, String, String, String, String, String) -> Unit
) {
    var reportType by remember { mutableStateOf(PostType.LOST) }
    var title by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Electronics") }
    var location by remember { mutableStateOf("Central Library") }
    var description by remember { mutableStateOf("") }
    var contactPref by remember { mutableStateOf("In-App Chat") }
    var photoAttached by remember { mutableStateOf(false) }

    var categoryExpanded by remember { mutableStateOf(false) }
    var locationExpanded by remember { mutableStateOf(false) }

    val categories = listOf(
        "Electronics",
        "ID Cards/Documents",
        "Keys",
        "Bags",
        "Clothing",
        "Others"
    )

    val locations = listOf(
        "Central Library",
        "Building A Canteen",
        "PG Hostel Block B",
        "Main Auditorium",
        "Sports Ground",
        "Bus & Visitor Parking",
        "Faculty Cabin / Admin"
    )

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .padding(vertical = 24.dp),
            shape = RoundedCornerShape(20.dp),
            color = MuSurface,
            shadowElevation = 8.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
            ) {
                // Modal Header
                Surface(
                    color = MuNavy,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Report an Item",
                            color = Color.White,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                        IconButton(
                            onClick = onDismiss,
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Close",
                                tint = Color.White.copy(alpha = 0.8f),
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }

                // Form Content
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f, fill = false)
                        .verticalScroll(rememberScrollState())
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Type Toggle (Lost vs Found)
                    Text(
                        text = "WHAT ARE YOU REPORTING?",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = MuTextMuted,
                        letterSpacing = 0.5.sp
                    )

                    Surface(
                        color = Color(0xFFF1F5F9),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(modifier = Modifier.padding(4.dp)) {
                            // Lost Option
                            val isLost = reportType == PostType.LOST
                            Surface(
                                color = if (isLost) MuCrimson else Color.Transparent,
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(10.dp))
                                    .clickable { reportType = PostType.LOST }
                                    .testTag("report_type_lost")
                            ) {
                                Row(
                                    modifier = Modifier.padding(vertical = 8.dp),
                                    horizontalArrangement = Arrangement.Center,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Warning,
                                        contentDescription = null,
                                        tint = if (isLost) Color.White else Color(0xFF64748B),
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "I Lost Something",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isLost) Color.White else Color(0xFF475569)
                                    )
                                }
                            }

                            // Found Option
                            val isFound = reportType == PostType.FOUND
                            Surface(
                                color = if (isFound) MuNavy else Color.Transparent,
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(10.dp))
                                    .clickable { reportType = PostType.FOUND }
                                    .testTag("report_type_found")
                            ) {
                                Row(
                                    modifier = Modifier.padding(vertical = 8.dp),
                                    horizontalArrangement = Arrangement.Center,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Handshake,
                                        contentDescription = null,
                                        tint = if (isFound) Color.White else Color(0xFF64748B),
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "I Found Something",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isFound) Color.White else Color(0xFF475569)
                                    )
                                }
                            }
                        }
                    }

                    // Item Title Field
                    Column {
                        Text(
                            text = "Item Title *",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MuTextMain
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        OutlinedTextField(
                            value = title,
                            onValueChange = { title = it },
                            placeholder = { Text("e.g., Apple AirPods Pro in Matte Gray Case", fontSize = 12.sp) },
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("report_title_input"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = MuNavy,
                                unfocusedBorderColor = MuBorder
                            ),
                            shape = RoundedCornerShape(10.dp)
                        )
                    }

                    // Category & Campus Spot Dropdowns
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Category Dropdown
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Category *",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = MuTextMain
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Box {
                                Surface(
                                    color = Color(0xFFF8FAFC),
                                    shape = RoundedCornerShape(10.dp),
                                    border = BorderStroke(1.dp, MuBorder),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(10.dp))
                                        .clickable { categoryExpanded = true }
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 11.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = category,
                                            fontSize = 11.sp,
                                            color = MuTextMain,
                                            maxLines = 1
                                        )
                                        Icon(
                                            imageVector = Icons.Default.ArrowDropDown,
                                            contentDescription = null,
                                            tint = MuTextMuted,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }

                                DropdownMenu(
                                    expanded = categoryExpanded,
                                    onDismissRequest = { categoryExpanded = false }
                                ) {
                                    categories.forEach { cat ->
                                        DropdownMenuItem(
                                            text = { Text(cat, fontSize = 12.sp) },
                                            onClick = {
                                                category = cat
                                                categoryExpanded = false
                                            }
                                        )
                                    }
                                }
                            }
                        }

                        // Location Dropdown
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Campus Spot *",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = MuTextMain
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Box {
                                Surface(
                                    color = Color(0xFFF8FAFC),
                                    shape = RoundedCornerShape(10.dp),
                                    border = BorderStroke(1.dp, MuBorder),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(10.dp))
                                        .clickable { locationExpanded = true }
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 11.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.LocationOn,
                                                contentDescription = null,
                                                tint = MuCrimson,
                                                modifier = Modifier.size(13.dp)
                                            )
                                            Spacer(modifier = Modifier.width(3.dp))
                                            Text(
                                                text = location,
                                                fontSize = 11.sp,
                                                color = MuTextMain,
                                                maxLines = 1
                                            )
                                        }
                                        Icon(
                                            imageVector = Icons.Default.ArrowDropDown,
                                            contentDescription = null,
                                            tint = MuTextMuted,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }

                                DropdownMenu(
                                    expanded = locationExpanded,
                                    onDismissRequest = { locationExpanded = false }
                                ) {
                                    locations.forEach { loc ->
                                        DropdownMenuItem(
                                            text = { Text(loc, fontSize = 12.sp) },
                                            onClick = {
                                                location = loc
                                                locationExpanded = false
                                            }
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // Description Field
                    Column {
                        Text(
                            text = "Detailed Description & Distinguishing Marks *",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MuTextMain
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        OutlinedTextField(
                            value = description,
                            onValueChange = { description = it },
                            placeholder = {
                                Text(
                                    "Mention color, stickers, scratch marks, serial clues (keep one secret detail for claim verification)...",
                                    fontSize = 11.sp
                                )
                            },
                            minLines = 3,
                            maxLines = 4,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("report_description_input"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = MuNavy,
                                unfocusedBorderColor = MuBorder
                            ),
                            shape = RoundedCornerShape(10.dp)
                        )
                    }

                    // Contact / Drop-off Preference
                    Column {
                        Text(
                            text = "Handoff / Contact Preference",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MuTextMain
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            listOf(
                                Triple("In-App Chat", Icons.Default.Sms, MuNavy),
                                Triple("Security Desk", Icons.Default.Shield, MuCrimson),
                                Triple("Student Phone", Icons.Default.Phone, Color(0xFF059669))
                            ).forEach { (pref, icon, iconColor) ->
                                val isSelected = contactPref == pref
                                Surface(
                                    color = if (isSelected) Color(0xFFEFF6FF) else Color(0xFFF8FAFC),
                                    shape = RoundedCornerShape(8.dp),
                                    border = BorderStroke(1.dp, if (isSelected) MuNavy else MuBorder),
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(8.dp))
                                        .clickable { contactPref = pref }
                                ) {
                                    Column(
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        modifier = Modifier.padding(vertical = 8.dp, horizontal = 4.dp)
                                    ) {
                                        Icon(
                                            imageVector = icon,
                                            contentDescription = null,
                                            tint = iconColor,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = pref,
                                            fontSize = 10.sp,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                            color = MuTextMain
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // Attach Photo Simulated Card
                    Surface(
                        color = Color(0xFFF8FAFC),
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, if (photoAttached) Color(0xFF10B981) else MuBorder),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .clickable { photoAttached = !photoAttached }
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = if (photoAttached) Icons.Default.Check else Icons.Default.AddPhotoAlternate,
                                contentDescription = "Attach Photo",
                                tint = if (photoAttached) Color(0xFF10B981) else MuTextMuted,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (photoAttached) "Photo attached: item_preview.jpg" else "Click to select photo or take picture",
                                fontSize = 11.sp,
                                fontWeight = if (photoAttached) FontWeight.Bold else FontWeight.Medium,
                                color = if (photoAttached) Color(0xFF047857) else MuTextMuted
                            )
                        }
                    }

                    // Submit Button
                    Button(
                        onClick = {
                            if (title.isNotBlank()) {
                                onSubmit(
                                    reportType,
                                    title.trim(),
                                    category,
                                    location,
                                    description.ifBlank { "Reported item on Marwadi University Campus." },
                                    contactPref
                                )
                            }
                        },
                        enabled = title.isNotBlank(),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MuNavy,
                            disabledContainerColor = Color(0xFF94A3B8)
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(44.dp)
                            .testTag("publish_post_button")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Send,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Publish Post to MU Campus",
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}
