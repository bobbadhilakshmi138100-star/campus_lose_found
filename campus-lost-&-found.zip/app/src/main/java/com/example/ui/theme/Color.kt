package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val MuNavy = Color(0xFF003366)
val MuNavyDark = Color(0xFF002244)
val MuNavyLight = Color(0xFF0A4A8F)
val MuCrimson = Color(0xFFD32F2F)
val MuCrimsonLight = Color(0xFFFFEBEE)
val MuCrimsonHover = Color(0xFFB71C1C)

val MuBg = Color(0xFFF1F5F9)
val MuSurface = Color(0xFFFFFFFF)
val MuBorder = Color(0xFFE2E8F0)
val MuTextMain = Color(0xFF1E293B)
val MuTextMuted = Color(0xFF64748B)

val MuSuccess = Color(0xFF10B981)
val MuSuccessBg = Color(0xFFECFDF5)
val MuSuccessBorder = Color(0xFFA7F3D0)
val MuWarning = Color(0xFFF59E0B)
val MuWarningBg = Color(0xFFFFFBEB)
val MuWarningBorder = Color(0xFFFDE68A)

val MuBlueTint = Color(0xFFEFF6FF)
val MuBlueBorder = Color(0xFFBFDBFE)
