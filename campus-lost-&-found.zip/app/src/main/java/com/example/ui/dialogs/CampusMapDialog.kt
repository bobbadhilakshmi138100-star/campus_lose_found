package com.example.ui.dialogs

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Place
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.ui.theme.MuBorder
import com.example.ui.theme.MuCrimson
import com.example.ui.theme.MuNavy
import com.example.ui.theme.MuSurface
import com.example.ui.theme.MuTextMain
import com.example.ui.theme.MuTextMuted

@Composable
fun CampusMapDialog(
    onSelectLocation: (String) -> Unit,
    onDismiss: () -> Unit
) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .padding(vertical = 24.dp),
            shape = RoundedCornerShape(20.dp),
            color = MuSurface,
            shadowElevation = 8.dp
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                // Header
                Surface(
                    color = MuNavy,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Place,
                                contentDescription = null,
                                tint = MuCrimson,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Marwadi University Campus Hotspots",
                                color = Color.White,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        IconButton(
                            onClick = onDismiss,
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Close",
                                tint = Color.White.copy(alpha = 0.8f),
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }

                // Body
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f, fill = false)
                        .verticalScroll(rememberScrollState())
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Stylized Campus Map Canvas
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(Color(0xFF0F172A))
                            .border(1.dp, Color(0xFF334155), RoundedCornerShape(14.dp))
                    ) {
                        Canvas(modifier = Modifier.matchParentSize()) {
                            val w = size.width
                            val h = size.height

                            // Draw subtle grid lines
                            val gridSpacing = 24.dp.toPx()
                            var x = 0f
                            while (x < w) {
                                drawLine(
                                    color = Color(0xFF1E293B),
                                    start = Offset(x, 0f),
                                    end = Offset(x, h),
                                    strokeWidth = 1f
                                )
                                x += gridSpacing
                            }
                            var y = 0f
                            while (y < h) {
                                drawLine(
                                    color = Color(0xFF1E293B),
                                    start = Offset(0f, y),
                                    end = Offset(w, y),
                                    strokeWidth = 1f
                                )
                                y += gridSpacing
                            }

                            // Draw campus highway loop
                            val roadPath = Path().apply {
                                moveTo(20f, h * 0.55f)
                                quadraticTo(w * 0.5f, h * 0.15f, w - 20f, h * 0.55f)
                            }
                            drawPath(
                                path = roadPath,
                                color = Color(0xFF475569),
                                style = Stroke(width = 12.dp.toPx())
                            )
                            drawPath(
                                path = roadPath,
                                color = Color(0xFF94A3B8),
                                style = Stroke(width = 2.dp.toPx())
                            )

                            // Cross avenues
                            drawLine(
                                color = Color(0xFF334155),
                                start = Offset(w * 0.3f, h * 0.9f),
                                end = Offset(w * 0.35f, h * 0.3f),
                                strokeWidth = 8.dp.toPx()
                            )
                            drawLine(
                                color = Color(0xFF334155),
                                start = Offset(w * 0.7f, h * 0.9f),
                                end = Offset(w * 0.65f, h * 0.3f),
                                strokeWidth = 8.dp.toPx()
                            )

                            // Central circle
                            drawCircle(
                                color = Color(0xFF003366).copy(alpha = 0.5f),
                                radius = 28.dp.toPx(),
                                center = Offset(w * 0.5f, h * 0.5f)
                            )
                            drawCircle(
                                color = Color(0xFF38BDF8),
                                radius = 28.dp.toPx(),
                                center = Offset(w * 0.5f, h * 0.5f),
                                style = Stroke(width = 1.5.dp.toPx())
                            )
                        }

                        // Center badge
                        Box(
                            modifier = Modifier
                                .align(Alignment.Center)
                                .clip(RoundedCornerShape(50))
                                .background(Color.Black.copy(alpha = 0.65f))
                                .border(1.dp, Color.White.copy(alpha = 0.2f), RoundedCornerShape(50))
                                .padding(horizontal = 8.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "MU Main Circle",
                                fontSize = 9.sp,
                                color = Color(0xFFE2E8F0),
                                fontWeight = FontWeight.SemiBold
                            )
                        }

                        // Pin 1: Library
                        MapPinItem(
                            number = "1",
                            label = "Library",
                            color = MuNavy,
                            modifier = Modifier
                                .align(Alignment.TopStart)
                                .offset(x = 32.dp, y = 20.dp),
                            onClick = {
                                onSelectLocation("Central Library")
                                onDismiss()
                            }
                        )

                        // Pin 2: Canteen
                        MapPinItem(
                            number = "2",
                            label = "Canteen",
                            color = MuCrimson,
                            modifier = Modifier
                                .align(Alignment.TopEnd)
                                .offset(x = (-32).dp, y = 24.dp),
                            onClick = {
                                onSelectLocation("Building A Canteen")
                                onDismiss()
                            }
                        )

                        // Pin 3: Hostel B
                        MapPinItem(
                            number = "3",
                            label = "Hostel B",
                            color = Color(0xFFF59E0B),
                            modifier = Modifier
                                .align(Alignment.BottomStart)
                                .offset(x = 52.dp, y = (-20).dp),
                            onClick = {
                                onSelectLocation("PG Hostel Block B")
                                onDismiss()
                            }
                        )

                        // Pin 4: Parking
                        MapPinItem(
                            number = "4",
                            label = "Parking",
                            color = Color(0xFF059669),
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .offset(x = (-52).dp, y = (-20).dp),
                            onClick = {
                                onSelectLocation("Bus & Visitor Parking")
                                onDismiss()
                            }
                        )
                    }

                    Text(
                        text = "Click on any campus zone to filter active reports:",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        color = MuTextMuted
                    )

                    // Hotspot List
                    Surface(
                        color = Color(0xFFF8FAFC),
                        shape = RoundedCornerShape(12.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, MuBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column {
                            listOf(
                                Triple("Central Library", "Central Library (3 Floors)", 2 to MuNavy),
                                Triple("Building A Canteen", "Building A Canteen & Food Court", 3 to MuCrimson),
                                Triple("PG Hostel Block B", "PG Hostel Block B Lounge", 1 to Color(0xFFF59E0B)),
                                Triple("Bus & Visitor Parking", "Bus & Visitor Parking Gate 2", 1 to Color(0xFF059669)),
                                Triple("Sports Ground", "Sports Ground & Pavilion", 0 to Color(0xFF6366F1))
                            ).forEachIndexed { index, (key, label, info) ->
                                val (count, dotColor) = info
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            onSelectLocation(key)
                                            onDismiss()
                                        }
                                        .padding(horizontal = 12.dp, vertical = 10.dp)
                                        .testTag("map_spot_$key"),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Box(
                                            modifier = Modifier
                                                .size(8.dp)
                                                .clip(CircleShape)
                                                .background(dotColor)
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = label,
                                            fontSize = 11.5.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            color = MuTextMain
                                        )
                                    }

                                    Surface(
                                        color = Color(0xFFE2E8F0),
                                        shape = RoundedCornerShape(50)
                                    ) {
                                        Text(
                                            text = "$count items",
                                            fontSize = 10.sp,
                                            color = Color(0xFF334155),
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }

                                if (index < 4) {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(1.dp)
                                            .background(Color(0xFFE2E8F0))
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MapPinItem(
    number: String,
    label: String,
    color: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier.clickable(onClick = onClick)
    ) {
        Box(
            modifier = Modifier
                .size(22.dp)
                .clip(CircleShape)
                .background(color)
                .border(2.dp, Color.White, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = number,
                color = Color.White,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold
            )
        }
        Spacer(modifier = Modifier.height(2.dp))
        Surface(
            color = Color.White.copy(alpha = 0.95f),
            shape = RoundedCornerShape(4.dp),
            shadowElevation = 1.dp
        ) {
            Text(
                text = label,
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF1E293B),
                modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
            )
        }
    }
}
