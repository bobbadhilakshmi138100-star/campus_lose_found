package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Map
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.PostType
import com.example.ui.theme.MuCrimson
import com.example.ui.theme.MuCrimsonLight
import com.example.ui.theme.MuNavy
import com.example.ui.theme.MuSuccess
import com.example.ui.theme.MuTextMain
import com.example.ui.theme.MuTextMuted

@Composable
fun DualFeedTabs(
    currentTab: PostType,
    onTabSelected: (PostType) -> Unit,
    lostCount: Int,
    foundCount: Int,
    onOpenMap: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)) {
        // Segmented Control Pill Container
        Surface(
            color = Color(0xFFE2E8F0),
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(3.dp)
            ) {
                // Lost Belongings Tab
                val isLostActive = currentTab == PostType.LOST
                Surface(
                    color = if (isLostActive) Color.White else Color.Transparent,
                    shape = RoundedCornerShape(11.dp),
                    shadowElevation = if (isLostActive) 2.dp else 0.dp,
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(11.dp))
                        .clickable { onTabSelected(PostType.LOST) }
                        .testTag("tab_lost_belongings")
                ) {
                    Row(
                        modifier = Modifier.padding(vertical = 9.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(7.dp)
                                .clip(CircleShape)
                                .background(MuCrimson)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Lost Belongings",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isLostActive) MuCrimson else Color(0xFF475569)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Surface(
                            color = if (isLostActive) MuCrimsonLight else Color(0xFFCBD5E1),
                            shape = CircleShape
                        ) {
                            Text(
                                text = lostCount.toString(),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = if (isLostActive) MuCrimson else Color(0xFF334155),
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 1.dp)
                            )
                        }
                    }
                }

                // Found Items Tab
                val isFoundActive = currentTab == PostType.FOUND
                Surface(
                    color = if (isFoundActive) Color.White else Color.Transparent,
                    shape = RoundedCornerShape(11.dp),
                    shadowElevation = if (isFoundActive) 2.dp else 0.dp,
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(11.dp))
                        .clickable { onTabSelected(PostType.FOUND) }
                        .testTag("tab_found_items")
                ) {
                    Row(
                        modifier = Modifier.padding(vertical = 9.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(7.dp)
                                .clip(CircleShape)
                                .background(MuSuccess)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Found Items",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isFoundActive) MuNavy else Color(0xFF475569)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Surface(
                            color = if (isFoundActive) Color(0xFFE2E8F0) else Color(0xFFCBD5E1),
                            shape = CircleShape
                        ) {
                            Text(
                                text = foundCount.toString(),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = if (isFoundActive) MuNavy else Color(0xFF334155),
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 1.dp)
                            )
                        }
                    }
                }
            }
        }

        // Subheader Info & Map View action
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 8.dp, bottom = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = if (currentTab == PostType.LOST) "Showing Lost Items" else "Showing Found Items",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = MuTextMain
                )
                Text(
                    text = " • Marwadi University Campus",
                    fontSize = 11.sp,
                    color = MuTextMuted
                )
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .clickable(onClick = onOpenMap)
                    .padding(horizontal = 4.dp, vertical = 2.dp)
                    .testTag("map_view_trigger")
            ) {
                Icon(
                    imageVector = Icons.Default.Map,
                    contentDescription = "Map View",
                    tint = MuNavy,
                    modifier = Modifier.size(13.dp)
                )
                Spacer(modifier = Modifier.width(3.dp))
                Text(
                    text = "Map View",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MuNavy
                )
            }
        }
    }
}
