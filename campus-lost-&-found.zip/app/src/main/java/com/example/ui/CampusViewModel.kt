package com.example.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.ChatMessage
import com.example.data.model.ItemCategory
import com.example.data.model.ItemPost
import com.example.data.model.ItemStatus
import com.example.data.model.PostType
import com.example.data.model.UserClaim
import com.example.data.repository.CampusRepository
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class CampusViewModel(
    private val repository: CampusRepository = CampusRepository()
) : ViewModel() {

    val allPosts = repository.posts
    val userClaims = repository.userClaims
    val chatHistories = repository.chatHistories

    val currentTab = MutableStateFlow(PostType.LOST)
    val currentCategory = MutableStateFlow(ItemCategory.ALL)
    val currentLocationFilter = MutableStateFlow("all")
    val searchQuery = MutableStateFlow("")
    val sortDescending = MutableStateFlow(true)

    // Dialog & UI Sheet States
    val showReportDialog = MutableStateFlow(false)
    val activeClaimItem = MutableStateFlow<ItemPost?>(null)
    val activeChatPost = MutableStateFlow<ItemPost?>(null)
    val showMapDialog = MutableStateFlow(false)
    val showSecurityDialog = MutableStateFlow(false)
    val showMyClaimsDialog = MutableStateFlow(false)
    val showNotificationAlert = MutableStateFlow(false)

    // Lost and Found counts
    val lostCount: StateFlow<Int> = repository.posts
        .combine(MutableStateFlow(Unit)) { posts, _ ->
            posts.count { it.type == PostType.LOST }
        }.stateIn(viewModelScope, SharingStarted.Eagerly, 3)

    val foundCount: StateFlow<Int> = repository.posts
        .combine(MutableStateFlow(Unit)) { posts, _ ->
            posts.count { it.type == PostType.FOUND }
        }.stateIn(viewModelScope, SharingStarted.Eagerly, 4)

    data class FilterParams(
        val tab: PostType,
        val cat: ItemCategory,
        val loc: String,
        val query: String,
        val desc: Boolean
    )

    private val filterParams = combine(
        currentTab,
        currentCategory,
        currentLocationFilter,
        searchQuery,
        sortDescending
    ) { tab, cat, loc, query, desc ->
        FilterParams(tab, cat, loc, query, desc)
    }

    // Filtered Feed
    val filteredPosts: StateFlow<List<ItemPost>> = combine(allPosts, filterParams) { posts, filter ->
        var list = posts.filter { it.type == filter.tab }

        if (filter.cat != ItemCategory.ALL) {
            list = list.filter {
                it.category.equals(filter.cat.rawCategory, ignoreCase = true) ||
                it.category.contains(filter.cat.displayName, ignoreCase = true)
            }
        }

        if (filter.loc != "all") {
            list = list.filter {
                it.location.contains(filter.loc, ignoreCase = true)
            }
        }

        if (filter.query.isNotBlank()) {
            val q = filter.query.trim().lowercase()
            list = list.filter {
                it.title.lowercase().contains(q) ||
                it.description.lowercase().contains(q) ||
                it.location.lowercase().contains(q) ||
                it.category.lowercase().contains(q) ||
                it.author.lowercase().contains(q)
            }
        }

        if (filter.desc) {
            list.sortedByDescending { it.timestamp }
        } else {
            list.sortedBy { it.timestamp }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun switchTab(type: PostType) {
        currentTab.value = type
    }

    fun selectCategory(cat: ItemCategory) {
        currentCategory.value = cat
    }

    fun setLocationFilter(loc: String) {
        currentLocationFilter.value = loc
    }

    fun setSearch(query: String) {
        searchQuery.value = query
    }

    fun toggleSort() {
        sortDescending.value = !sortDescending.value
    }

    fun resetFilters() {
        searchQuery.value = ""
        currentLocationFilter.value = "all"
        currentCategory.value = ItemCategory.ALL
    }

    fun cycleStatus(postId: String) {
        repository.cyclePostStatus(postId)
    }

    fun resolvePost(postId: String) {
        repository.setPostStatus(postId, ItemStatus.RESOLVED)
    }

    fun reportItem(
        type: PostType,
        title: String,
        category: String,
        location: String,
        description: String,
        contactPref: String
    ) {
        val newPost = repository.addPost(
            type = type,
            title = title,
            category = category,
            location = location,
            description = description,
            contactPref = contactPref
        )
        // Automatically switch to the tab where the item was published
        currentTab.value = type
        showReportDialog.value = false
    }

    fun submitClaim(
        post: ItemPost,
        claimantName: String,
        claimantId: String,
        proof: String,
        channel: String
    ) {
        repository.submitClaim(
            postId = post.id,
            itemTitle = post.title,
            claimantName = claimantName,
            claimantId = claimantId,
            proof = proof,
            preferredChannel = channel
        )
        activeClaimItem.value = null
        // Immediately open chat for verification
        activeChatPost.value = post
    }

    fun sendChat(postId: String, text: String) {
        val nowStr = SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date())
        repository.sendChatMessage(postId, "me", text, nowStr)

        // Realistic simulated counterpart response
        viewModelScope.launch {
            delay(900)
            val counterpartReplies = listOf(
                "Got your message! Let's meet at the designated spot or Security Desk.",
                "Thanks for confirming. I'll have the item ready for handoff.",
                "Understood! Please bring your MU ID card when collecting.",
                "Thank you for reaching out, verifying the identification now."
            )
            repository.sendChatMessage(
                postId,
                "them",
                counterpartReplies.random(),
                SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date())
            )
        }
    }
}
