package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Checkroom
import androidx.compose.material.icons.filled.Devices
import androidx.compose.material.icons.filled.Headphones
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PanTool
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.Power
import androidx.compose.material.icons.filled.QuestionMark
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.Sms
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ItemPost
import com.example.data.model.ItemStatus
import com.example.data.model.PostType
import com.example.ui.theme.MuBorder
import com.example.ui.theme.MuCrimson
import com.example.ui.theme.MuCrimsonLight
import com.example.ui.theme.MuNavy
import com.example.ui.theme.MuSuccess
import com.example.ui.theme.MuSuccessBg
import com.example.ui.theme.MuSuccessBorder
import com.example.ui.theme.MuSurface
import com.example.ui.theme.MuTextMain
import com.example.ui.theme.MuTextMuted
import com.example.ui.theme.MuWarning
import com.example.ui.theme.MuWarningBg
import com.example.ui.theme.MuWarningBorder

@Composable
fun ItemCard(
    item: ItemPost,
    onClaimClick: () -> Unit,
    onChatClick: () -> Unit,
    onCycleStatus: () -> Unit,
    modifier: Modifier = Modifier
) {
    var menuExpanded by remember { mutableStateOf(false) }

    Surface(
        color = MuSurface,
        shape = RoundedCornerShape(18.dp),
        border = BorderStroke(1.dp, MuBorder.copy(alpha = 0.8f)),
        shadowElevation = 1.dp,
        modifier = modifier
            .fillMaxWidth()
            .testTag("item_card_${item.id}")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Top Section: Thumbnail + Item Details
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.Top
            ) {
                // Item Visual Thumbnail Box
                Box(
                    modifier = Modifier
                        .size(68.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(getThumbnailBg(item.iconType, item.category))
                        .border(1.dp, MuBorder.copy(alpha = 0.5f), RoundedCornerShape(14.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = getItemIcon(item.iconType, item.category),
                        contentDescription = item.category,
                        tint = getThumbnailTint(item.iconType, item.category),
                        modifier = Modifier.size(34.dp)
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                // Content Area
                Column(modifier = Modifier.weight(1f)) {
                    // Type Badge & Status Badge Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Lost / Found Badge
                        if (item.type == PostType.LOST) {
                            Surface(
                                color = MuCrimsonLight,
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    text = "LOST ITEM",
                                    color = MuCrimson,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    letterSpacing = 0.5.sp,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        } else {
                            Surface(
                                color = Color(0xFFD1FAE5),
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    text = "FOUND ITEM",
                                    color = Color(0xFF065F46),
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    letterSpacing = 0.5.sp,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }

                        // Status Badge
                        StatusBadge(status = item.status)
                    }

                    Spacer(modifier = Modifier.height(5.dp))

                    // Title
                    Text(
                        text = item.title,
                        fontSize = 13.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = MuTextMain,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    // Location & Timestamp Badges
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(
                            imageVector = Icons.Default.Place,
                            contentDescription = "Location",
                            tint = MuCrimson,
                            modifier = Modifier.size(13.dp)
                        )
                        Spacer(modifier = Modifier.width(2.dp))
                        Text(
                            text = item.location,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFF334155),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f, fill = false)
                        )
                        Spacer(modifier = Modifier.width(5.dp))
                        Text(
                            text = "•",
                            fontSize = 11.sp,
                            color = Color(0xFFCBD5E1)
                        )
                        Spacer(modifier = Modifier.width(5.dp))
                        Icon(
                            imageVector = Icons.Default.AccessTime,
                            contentDescription = "Time",
                            tint = MuTextMuted,
                            modifier = Modifier.size(12.dp)
                        )
                        Spacer(modifier = Modifier.width(3.dp))
                        Text(
                            text = item.dateDisplay,
                            fontSize = 11.sp,
                            color = MuTextMuted,
                            maxLines = 1
                        )
                    }

                    Spacer(modifier = Modifier.height(5.dp))

                    // Short description preview
                    Text(
                        text = item.description,
                        fontSize = 11.5.sp,
                        color = Color(0xFF475569),
                        lineHeight = 16.sp,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Card Bottom Bar & Interactive Actions
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(1.dp)
                    .background(Color(0xFFF1F5F9))
            )

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Author info
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f, fill = false)
                ) {
                    Box(
                        modifier = Modifier
                            .size(22.dp)
                            .clip(CircleShape)
                            .background(Color(0xFFF1F5F9))
                            .border(1.dp, MuBorder, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = item.avatarInitials,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF475569)
                        )
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "${item.author} (${item.authorRole})",
                        fontSize = 11.sp,
                        color = MuTextMuted,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                // Action buttons: Claim (if Found & Active), Chat, 3-dots
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (item.type == PostType.FOUND && item.status != ItemStatus.RESOLVED) {
                        Surface(
                            color = Color(0xFF059669),
                            shape = RoundedCornerShape(8.dp),
                            shadowElevation = 1.dp,
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .clickable(onClick = onClaimClick)
                                .testTag("claim_button_${item.id}")
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.PanTool,
                                    contentDescription = "Claim",
                                    tint = Color.White,
                                    modifier = Modifier.size(11.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "Claim Item",
                                    color = Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                    }

                    // Chat button
                    Surface(
                        color = Color(0xFFF1F5F9),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .clickable(onClick = onChatClick)
                            .testTag("chat_button_${item.id}")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Sms,
                                contentDescription = "Chat",
                                tint = MuNavy,
                                modifier = Modifier.size(12.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Chat",
                                color = MuNavy,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }

                    // 3-dots options menu
                    Box {
                        IconButton(
                            onClick = { menuExpanded = true },
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.MoreVert,
                                contentDescription = "Options",
                                tint = MuTextMuted,
                                modifier = Modifier.size(16.dp)
                            )
                        }

                        DropdownMenu(
                            expanded = menuExpanded,
                            onDismissRequest = { menuExpanded = false }
                        ) {
                            DropdownMenuItem(
                                text = { Text("Toggle Status: Next Phase", fontSize = 12.sp) },
                                onClick = {
                                    onCycleStatus()
                                    menuExpanded = false
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Contact: ${item.contactPref}", fontSize = 12.sp) },
                                onClick = { menuExpanded = false }
                            )
                            DropdownMenuItem(
                                text = { Text("Open Chat Thread", fontSize = 12.sp) },
                                onClick = {
                                    onChatClick()
                                    menuExpanded = false
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun StatusBadge(status: ItemStatus) {
    when (status) {
        ItemStatus.ACTIVE -> {
            Surface(
                color = MuSuccessBg,
                shape = RoundedCornerShape(50),
                border = BorderStroke(1.dp, MuSuccessBorder)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(5.dp)
                            .clip(CircleShape)
                            .background(MuSuccess)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Active",
                        color = Color(0xFF047857),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
        ItemStatus.UNDER_VERIFICATION -> {
            Surface(
                color = MuWarningBg,
                shape = RoundedCornerShape(50),
                border = BorderStroke(1.dp, MuWarningBorder)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(5.dp)
                            .clip(CircleShape)
                            .background(MuWarning)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Under Verification",
                        color = Color(0xFFB45309),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
        ItemStatus.CLAIMED -> {
            Surface(
                color = Color(0xFFEFF6FF),
                shape = RoundedCornerShape(50),
                border = BorderStroke(1.dp, Color(0xFFBFDBFE))
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.PanTool,
                        contentDescription = null,
                        tint = MuNavy,
                        modifier = Modifier.size(9.dp)
                    )
                    Spacer(modifier = Modifier.width(3.dp))
                    Text(
                        text = "Claimed",
                        color = MuNavy,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
        ItemStatus.RESOLVED -> {
            Surface(
                color = Color(0xFFF1F5F9),
                shape = RoundedCornerShape(50),
                border = BorderStroke(1.dp, Color(0xFFE2E8F0))
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Check,
                        contentDescription = null,
                        tint = Color(0xFF64748B),
                        modifier = Modifier.size(10.dp)
                    )
                    Spacer(modifier = Modifier.width(3.dp))
                    Text(
                        text = "Returned / Resolved",
                        color = Color(0xFF475569),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

private fun getItemIcon(iconType: String, category: String): ImageVector {
    return when {
        iconType == "airpods" -> Icons.Default.Headphones
        iconType == "charger" -> Icons.Default.Power
        iconType == "calculator" -> Icons.Default.Calculate
        iconType == "id-card" || category.contains("ID", true) -> Icons.Default.Badge
        iconType == "key" || category.contains("Key", true) -> Icons.Default.Key
        iconType == "backpack" || category.contains("Bag", true) -> Icons.Default.ShoppingBag
        iconType == "glasses" -> Icons.Default.Visibility
        category.contains("Clothing", true) -> Icons.Default.Checkroom
        category.contains("Electronics", true) -> Icons.Default.Devices
        else -> Icons.Default.QuestionMark
    }
}

private fun getThumbnailBg(iconType: String, category: String): Color {
    return when {
        iconType == "id-card" || category.contains("ID", true) -> Color(0xFFEFF6FF)
        iconType == "key" || category.contains("Key", true) -> Color(0xFFFFF1F2)
        iconType == "backpack" || category.contains("Bag", true) -> Color(0xFFECFDF5)
        iconType == "glasses" -> Color(0xFFFAF5FF)
        else -> Color(0xFFF1F5F9)
    }
}

private fun getThumbnailTint(iconType: String, category: String): Color {
    return when {
        iconType == "id-card" || category.contains("ID", true) -> MuNavy
        iconType == "key" || category.contains("Key", true) -> MuCrimson
        iconType == "backpack" || category.contains("Bag", true) -> Color(0xFF047857)
        iconType == "glasses" -> Color(0xFF7E22CE)
        else -> Color(0xFF334155)
    }
}
