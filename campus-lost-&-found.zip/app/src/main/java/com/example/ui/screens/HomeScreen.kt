package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.SearchOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.model.ItemPost
import com.example.ui.CampusViewModel
import com.example.ui.components.AppBottomNav
import com.example.ui.components.AppTopHeader
import com.example.ui.components.DualFeedTabs
import com.example.ui.components.ItemCard
import com.example.ui.components.SearchBarAndFilters
import com.example.ui.dialogs.CampusMapDialog
import com.example.ui.dialogs.ClaimItemDialog
import com.example.ui.dialogs.MyClaimsDialog
import com.example.ui.dialogs.ReportItemDialog
import com.example.ui.dialogs.SecurityDeskDialog
import com.example.ui.dialogs.VerificationChatDialog
import com.example.ui.theme.MuBg
import com.example.ui.theme.MuNavy
import com.example.ui.theme.MuTextMain
import com.example.ui.theme.MuTextMuted

@Composable
fun HomeScreen(
    viewModel: CampusViewModel = viewModel(),
    modifier: Modifier = Modifier
) {
    val currentTab by viewModel.currentTab.collectAsState()
    val currentCategory by viewModel.currentCategory.collectAsState()
    val currentLocationFilter by viewModel.currentLocationFilter.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val isDescending by viewModel.sortDescending.collectAsState()

    val filteredPosts by viewModel.filteredPosts.collectAsState()
    val lostCount by viewModel.lostCount.collectAsState()
    val foundCount by viewModel.foundCount.collectAsState()

    val showReportDialog by viewModel.showReportDialog.collectAsState()
    val activeClaimItem by viewModel.activeClaimItem.collectAsState()
    val activeChatPost by viewModel.activeChatPost.collectAsState()
    val showMapDialog by viewModel.showMapDialog.collectAsState()
    val showSecurityDialog by viewModel.showSecurityDialog.collectAsState()
    val showMyClaimsDialog by viewModel.showMyClaimsDialog.collectAsState()
    val showNotificationAlert by viewModel.showNotificationAlert.collectAsState()

    val chatHistories by viewModel.chatHistories.collectAsState()
    val userClaims by viewModel.userClaims.collectAsState()

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .background(MuNavy)
            .statusBarsPadding(),
        topBar = {
            AppTopHeader(
                onNotificationsClick = { viewModel.showNotificationAlert.value = true },
                onSecurityClick = { viewModel.showSecurityDialog.value = true }
            )
        },
        bottomBar = {
            AppBottomNav(
                currentTab = currentTab,
                onTabSelected = { viewModel.switchTab(it) },
                onReportClick = { viewModel.showReportDialog.value = true },
                onMapClick = { viewModel.showMapDialog.value = true },
                onClaimsClick = { viewModel.showMyClaimsDialog.value = true }
            )
        },
        containerColor = MuBg
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Search and Filter Bar
            SearchBarAndFilters(
                searchQuery = searchQuery,
                onSearchChange = { viewModel.setSearch(it) },
                selectedCategory = currentCategory,
                onSelectCategory = { viewModel.selectCategory(it) },
                selectedLocation = currentLocationFilter,
                onSelectLocation = { viewModel.setLocationFilter(it) },
                isDescending = isDescending,
                onToggleSort = { viewModel.toggleSort() }
            )

            // Dual Segmented Tabs: Lost Belongings vs Found Items
            DualFeedTabs(
                currentTab = currentTab,
                onTabSelected = { viewModel.switchTab(it) },
                lostCount = lostCount,
                foundCount = foundCount,
                onOpenMap = { viewModel.showMapDialog.value = true }
            )

            // Items Feed List
            if (filteredPosts.isEmpty()) {
                // Empty State
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .padding(horizontal = 24.dp, vertical = 36.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(56.dp)
                            .clip(CircleShape)
                            .background(Color(0xFFE2E8F0)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.SearchOff,
                            contentDescription = null,
                            tint = MuTextMuted,
                            modifier = Modifier.size(28.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "No matching items found",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = MuTextMain
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Try loosening your search keywords or switching between Lost and Found tabs.",
                        fontSize = 11.5.sp,
                        color = MuTextMuted,
                        textAlign = TextAlign.Center,
                        lineHeight = 16.sp
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                    Button(
                        onClick = { viewModel.resetFilters() },
                        colors = ButtonDefaults.buttonColors(containerColor = MuNavy),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = "Reset Filters",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .testTag("feed_items_list"),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(filteredPosts, key = { it.id }) { item ->
                        ItemCard(
                            item = item,
                            onClaimClick = { viewModel.activeClaimItem.value = item },
                            onChatClick = { viewModel.activeChatPost.value = item },
                            onCycleStatus = { viewModel.cycleStatus(item.id) }
                        )
                    }
                    item {
                        Spacer(modifier = Modifier.height(16.dp))
                    }
                }
            }
        }
    }

    // ================== DIALOGS ==================

    // 1. Report Dialog
    if (showReportDialog) {
        ReportItemDialog(
            onDismiss = { viewModel.showReportDialog.value = false },
            onSubmit = { type, title, cat, loc, desc, pref ->
                viewModel.reportItem(type, title, cat, loc, desc, pref)
            }
        )
    }

    // 2. Claim Dialog
    activeClaimItem?.let { item ->
        ClaimItemDialog(
            item = item,
            onDismiss = { viewModel.activeClaimItem.value = null },
            onSubmit = { name, id, proof, channel ->
                viewModel.submitClaim(item, name, id, proof, channel)
            }
        )
    }

    // 3. Verification Chat Dialog
    activeChatPost?.let { post ->
        val messages = chatHistories[post.id] ?: emptyList()
        VerificationChatDialog(
            item = post,
            messages = messages,
            onSendMessage = { text -> viewModel.sendChat(post.id, text) },
            onResolveClick = {
                viewModel.resolvePost(post.id)
                viewModel.activeChatPost.value = null
            },
            onDismiss = { viewModel.activeChatPost.value = null }
        )
    }

    // 4. Campus Map Hotspots Dialog
    if (showMapDialog) {
        CampusMapDialog(
            onSelectLocation = { loc ->
                viewModel.setLocationFilter(loc)
            },
            onDismiss = { viewModel.showMapDialog.value = false }
        )
    }

    // 5. Security Desk Dialog
    if (showSecurityDialog) {
        SecurityDeskDialog(
            onDismiss = { viewModel.showSecurityDialog.value = false }
        )
    }

    // 6. My Claims Dialog
    if (showMyClaimsDialog) {
        MyClaimsDialog(
            claims = userClaims,
            onOpenChat = { postId ->
                viewModel.showMyClaimsDialog.value = false
                val targetPost = viewModel.allPosts.value.firstOrNull { it.id == postId }
                if (targetPost != null) {
                    viewModel.activeChatPost.value = targetPost
                }
            },
            onDismiss = { viewModel.showMyClaimsDialog.value = false }
        )
    }

    // 7. Campus Notifications Alert
    if (showNotificationAlert) {
        AlertDialog(
            onDismissRequest = { viewModel.showNotificationAlert.value = false },
            icon = {
                Icon(
                    imageVector = Icons.Default.NotificationsActive,
                    contentDescription = null,
                    tint = MuNavy
                )
            },
            title = {
                Text(
                    text = "Campus Lost & Found Alerts",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Text(
                    text = "No pending urgent alerts. You are currently tracking all campus broadcasts for Gauridad, Rajkot Highway campus zones.",
                    fontSize = 12.sp,
                    color = MuTextMuted,
                    lineHeight = 17.sp
                )
            },
            confirmButton = {
                TextButton(onClick = { viewModel.showNotificationAlert.value = false }) {
                    Text("OK", color = MuNavy, fontWeight = FontWeight.Bold)
                }
            }
        )
    }
}
