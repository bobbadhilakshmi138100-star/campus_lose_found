package com.example.ui.dialogs

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.ItemPost
import com.example.ui.theme.MuBorder
import com.example.ui.theme.MuCrimson
import com.example.ui.theme.MuNavy
import com.example.ui.theme.MuSurface
import com.example.ui.theme.MuTextMain
import com.example.ui.theme.MuTextMuted
import com.example.ui.theme.MuWarning
import com.example.ui.theme.MuWarningBg
import com.example.ui.theme.MuWarningBorder

@Composable
fun ClaimItemDialog(
    item: ItemPost,
    onDismiss: () -> Unit,
    onSubmit: (claimantName: String, claimantId: String, proof: String, channel: String) -> Unit
) {
    var claimantNameAndId by remember { mutableStateOf("") }
    var proofText by remember { mutableStateOf("") }
    var channel by remember { mutableStateOf("Immediate In-App Chat with Finder") }
    var channelExpanded by remember { mutableStateOf(false) }

    val channels = listOf(
        "Immediate In-App Chat with Finder",
        "Meet at Security Desk (Main Gate 1)",
        "Submit to Student Affairs Office"
    )

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .padding(vertical = 24.dp),
            shape = RoundedCornerShape(20.dp),
            color = MuSurface,
            shadowElevation = 8.dp
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                // Header
                Surface(
                    color = MuNavy,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Shield,
                                contentDescription = null,
                                tint = Color(0xFF34D399),
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Ownership Claim & Verification",
                                color = Color.White,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        IconButton(
                            onClick = onDismiss,
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Close",
                                tint = Color.White.copy(alpha = 0.8f),
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }

                // Body
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f, fill = false)
                        .verticalScroll(rememberScrollState())
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Target Item Preview Card
                    Surface(
                        color = Color(0xFFF8FAFC),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, MuBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(44.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color(0xFFE2E8F0)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = item.title.take(2).uppercase(),
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MuNavy
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "FOUND ITEM CLAIM",
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MuNavy
                                )
                                Text(
                                    text = item.title,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MuTextMain,
                                    maxLines = 1
                                )
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.Place,
                                        contentDescription = null,
                                        tint = MuCrimson,
                                        modifier = Modifier.size(11.dp)
                                    )
                                    Spacer(modifier = Modifier.width(2.dp))
                                    Text(
                                        text = item.location,
                                        fontSize = 11.sp,
                                        color = MuTextMuted
                                    )
                                }
                            }
                        }
                    }

                    // Security Callout Warning
                    Surface(
                        color = MuWarningBg,
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, MuWarningBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            verticalAlignment = Alignment.Top
                        ) {
                            Icon(
                                imageVector = Icons.Default.Info,
                                contentDescription = null,
                                tint = MuWarning,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = "Security Question Verification",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF92400E)
                                )
                                Text(
                                    text = "To prevent false claims, provide specific proof (e.g., wallpaper description, serial/ID number, distinctive stickers or marks, pouch color).",
                                    fontSize = 10.5.sp,
                                    color = Color(0xFFB45309),
                                    lineHeight = 14.sp
                                )
                            }
                        }
                    }

                    // Claimant Name & Student ID
                    Column {
                        Text(
                            text = "Your Full Name & MU Student/Faculty ID *",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MuTextMain
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        OutlinedTextField(
                            value = claimantNameAndId,
                            onValueChange = { claimantNameAndId = it },
                            placeholder = { Text("e.g., Aarav Patel (MU2022CS089)", fontSize = 12.sp) },
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("claimant_id_input"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = MuNavy,
                                unfocusedBorderColor = MuBorder
                            ),
                            shape = RoundedCornerShape(10.dp)
                        )
                    }

                    // Proof of Ownership
                    Column {
                        Text(
                            text = "Proof of Ownership / Distinguishing Feature *",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MuTextMain
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        OutlinedTextField(
                            value = proofText,
                            onValueChange = { proofText = it },
                            placeholder = {
                                Text(
                                    "Describe the item's unseen details that only the true owner would know...",
                                    fontSize = 11.sp
                                )
                            },
                            minLines = 3,
                            maxLines = 4,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("claim_proof_input"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = MuNavy,
                                unfocusedBorderColor = MuBorder
                            ),
                            shape = RoundedCornerShape(10.dp)
                        )
                    }

                    // Preferred Verification Channel
                    Column {
                        Text(
                            text = "Preferred Verification Channel",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MuTextMain
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Box {
                            Surface(
                                color = Color(0xFFF8FAFC),
                                shape = RoundedCornerShape(10.dp),
                                border = BorderStroke(1.dp, MuBorder),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(10.dp))
                                    .clickable { channelExpanded = true }
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 11.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = channel,
                                        fontSize = 11.sp,
                                        color = MuTextMain,
                                        maxLines = 1
                                    )
                                    Icon(
                                        imageVector = Icons.Default.ArrowDropDown,
                                        contentDescription = null,
                                        tint = MuTextMuted,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }

                            DropdownMenu(
                                expanded = channelExpanded,
                                onDismissRequest = { channelExpanded = false }
                            ) {
                                channels.forEach { ch ->
                                    DropdownMenuItem(
                                        text = { Text(ch, fontSize = 12.sp) },
                                        onClick = {
                                            channel = ch
                                            channelExpanded = false
                                        }
                                    )
                                }
                            }
                        }
                    }

                    // Submit Button
                    Button(
                        onClick = {
                            if (claimantNameAndId.isNotBlank() && proofText.isNotBlank()) {
                                onSubmit(
                                    claimantNameAndId.substringBefore("(").trim(),
                                    claimantNameAndId.trim(),
                                    proofText.trim(),
                                    channel
                                )
                            }
                        },
                        enabled = claimantNameAndId.isNotBlank() && proofText.isNotBlank(),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF059669),
                            disabledContainerColor = Color(0xFF94A3B8)
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(44.dp)
                            .testTag("submit_claim_button")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Submit Claim & Open Verification Chat",
                                color = Color.White,
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}
