package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = Color(0xFF90CAF9),
    onPrimary = Color(0xFF001E3D),
    primaryContainer = MuNavy,
    onPrimaryContainer = Color(0xFFD1E4FF),
    secondary = Color(0xFFFFB4AB),
    onSecondary = Color(0xFF690005),
    secondaryContainer = MuCrimsonHover,
    onSecondaryContainer = Color(0xFFFFDAD6),
    background = Color(0xFF0F172A),
    surface = Color(0xFF1E293B),
    onBackground = Color(0xFFF1F5F9),
    onSurface = Color(0xFFF1F5F9),
    surfaceVariant = Color(0xFF334155),
    onSurfaceVariant = Color(0xFFCBD5E1),
    outline = Color(0xFF64748B)
)

private val LightColorScheme = lightColorScheme(
    primary = MuNavy,
    onPrimary = Color.White,
    primaryContainer = MuNavyLight,
    onPrimaryContainer = Color.White,
    secondary = MuCrimson,
    onSecondary = Color.White,
    secondaryContainer = MuCrimsonLight,
    onSecondaryContainer = MuCrimsonHover,
    background = MuBg,
    surface = MuSurface,
    onBackground = MuTextMain,
    onSurface = MuTextMain,
    surfaceVariant = Color(0xFFF8FAFC),
    onSurfaceVariant = MuTextMuted,
    outline = MuBorder
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Use intentional campus palette
    content: @Composable () -> Unit,
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
