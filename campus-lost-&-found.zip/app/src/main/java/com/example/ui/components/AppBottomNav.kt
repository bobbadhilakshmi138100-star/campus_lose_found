package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Forum
import androidx.compose.material.icons.filled.Handshake
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.PostType
import com.example.ui.theme.MuBorder
import com.example.ui.theme.MuCrimson
import com.example.ui.theme.MuNavy
import com.example.ui.theme.MuNavyLight
import com.example.ui.theme.MuSurface
import com.example.ui.theme.MuTextMuted

@Composable
fun AppBottomNav(
    currentTab: PostType,
    onTabSelected: (PostType) -> Unit,
    onReportClick: () -> Unit,
    onMapClick: () -> Unit,
    onClaimsClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        color = MuSurface.copy(alpha = 0.98f),
        border = androidx.compose.foundation.BorderStroke(1.dp, MuBorder),
        shadowElevation = 12.dp,
        modifier = modifier.fillMaxWidth()
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(vertical = 6.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceAround,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Lost Feed Button
                BottomNavItem(
                    icon = Icons.Default.Search,
                    label = "Lost Feed",
                    isSelected = currentTab == PostType.LOST,
                    activeColor = MuCrimson,
                    onClick = { onTabSelected(PostType.LOST) },
                    testTag = "nav_lost_feed"
                )

                // Found Feed Button
                BottomNavItem(
                    icon = Icons.Default.Handshake,
                    label = "Found Feed",
                    isSelected = currentTab == PostType.FOUND,
                    activeColor = MuNavy,
                    onClick = { onTabSelected(PostType.FOUND) },
                    testTag = "nav_found_feed"
                )

                // Spacer for Center Big FAB
                Spacer(modifier = Modifier.size(48.dp))

                // Campus Map Button
                BottomNavItem(
                    icon = Icons.Default.LocationOn,
                    label = "Campus Map",
                    isSelected = false,
                    activeColor = MuNavy,
                    onClick = onMapClick,
                    testTag = "nav_campus_map"
                )

                // My Claims Button
                BottomNavItem(
                    icon = Icons.Default.Forum,
                    label = "My Claims",
                    isSelected = false,
                    activeColor = MuNavy,
                    onClick = onClaimsClick,
                    testTag = "nav_my_claims"
                )
            }

            // Center Elevated Report Button
            Box(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .offset(y = (-18).dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(54.dp)
                        .shadow(8.dp, CircleShape)
                        .clip(CircleShape)
                        .background(
                            Brush.linearGradient(
                                colors = listOf(MuNavy, MuNavyLight)
                            )
                        )
                        .border(3.5.dp, Color.White, CircleShape)
                        .clickable(onClick = onReportClick)
                        .testTag("report_item_fab"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "Report Item",
                        tint = Color.White,
                        modifier = Modifier.size(28.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun BottomNavItem(
    icon: ImageVector,
    label: String,
    isSelected: Boolean,
    activeColor: Color,
    onClick: () -> Unit,
    testTag: String
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clip(CircleShape)
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 4.dp)
            .testTag(testTag)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = if (isSelected) activeColor else MuTextMuted,
            modifier = Modifier.size(22.dp)
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = label,
            fontSize = 10.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
            color = if (isSelected) activeColor else MuTextMuted
        )
    }
}
