package com.example.data.model

enum class PostType(val label: String) {
    LOST("Lost Belongings"),
    FOUND("Found Items")
}

enum class ItemCategory(val displayName: String, val rawCategory: String) {
    ALL("All Categories", "all"),
    ELECTRONICS("Electronics", "Electronics"),
    ID_DOCS("ID & Docs", "ID Cards/Documents"),
    KEYS("Keys", "Keys"),
    BAGS("Bags", "Bags"),
    CLOTHING("Clothing", "Clothing"),
    OTHERS("Others", "Others")
}

enum class ItemStatus(val displayName: String) {
    ACTIVE("Active"),
    UNDER_VERIFICATION("Under Verification"),
    CLAIMED("Claimed"),
    RESOLVED("Returned / Resolved")
}

data class ItemPost(
    val id: String,
    val type: PostType,
    val title: String,
    val category: String,
    val location: String,
    val locationDetail: String = "",
    val dateDisplay: String,
    val timestamp: Long = System.currentTimeMillis(),
    val status: ItemStatus = ItemStatus.ACTIVE,
    val description: String,
    val contactPref: String = "In-App Chat",
    val author: String,
    val authorRole: String = "Student",
    val avatarInitials: String,
    val iconType: String = "default",
    val imageUrl: String? = null
)

data class UserClaim(
    val id: String,
    val postId: String,
    val itemTitle: String,
    val claimantName: String,
    val claimantId: String,
    val proof: String,
    val preferredChannel: String,
    val status: String,
    val timestamp: Long = System.currentTimeMillis()
)

data class ChatMessage(
    val id: String,
    val sender: String, // "me" or "them"
    val text: String,
    val time: String,
    val timestamp: Long = System.currentTimeMillis()
)
