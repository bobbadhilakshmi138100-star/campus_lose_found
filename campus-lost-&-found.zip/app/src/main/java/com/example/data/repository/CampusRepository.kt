package com.example.data.repository

import com.example.data.model.ChatMessage
import com.example.data.model.ItemPost
import com.example.data.model.ItemStatus
import com.example.data.model.PostType
import com.example.data.model.UserClaim
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class CampusRepository {

    private val _posts = MutableStateFlow<List<ItemPost>>(getInitialPosts())
    val posts: StateFlow<List<ItemPost>> = _posts.asStateFlow()

    private val _userClaims = MutableStateFlow<List<UserClaim>>(getInitialClaims())
    val userClaims: StateFlow<List<UserClaim>> = _userClaims.asStateFlow()

    private val _chatHistories = MutableStateFlow<Map<String, List<ChatMessage>>>(getInitialChatHistories())
    val chatHistories: StateFlow<Map<String, List<ChatMessage>>> = _chatHistories.asStateFlow()

    fun addPost(
        type: PostType,
        title: String,
        category: String,
        location: String,
        locationDetail: String = "",
        description: String,
        contactPref: String = "In-App Chat"
    ): ItemPost {
        val now = System.currentTimeMillis()
        val timeStr = SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date(now))
        val newPost = ItemPost(
            id = "post-${System.currentTimeMillis()}",
            type = type,
            title = title,
            category = category,
            location = location,
            locationDetail = locationDetail,
            dateDisplay = "Today, $timeStr",
            timestamp = now,
            status = ItemStatus.ACTIVE,
            description = description,
            contactPref = contactPref,
            author = "Current User (You)",
            authorRole = "Student",
            avatarInitials = "YOU",
            iconType = when {
                category.contains("ID", ignoreCase = true) -> "id-card"
                category.contains("Key", ignoreCase = true) -> "key"
                category.contains("Bag", ignoreCase = true) -> "backpack"
                category.contains("Cloth", ignoreCase = true) -> "clothing"
                category.contains("Elect", ignoreCase = true) -> "electronics"
                else -> "default"
            }
        )
        _posts.value = listOf(newPost) + _posts.value
        return newPost
    }

    fun cyclePostStatus(postId: String) {
        val currentList = _posts.value.toMutableList()
        val index = currentList.indexOfFirst { it.id == postId }
        if (index != -1) {
            val item = currentList[index]
            val allStatuses = ItemStatus.values()
            val nextStatus = allStatuses[(item.status.ordinal + 1) % allStatuses.size]
            currentList[index] = item.copy(status = nextStatus)
            _posts.value = currentList
        }
    }

    fun setPostStatus(postId: String, status: ItemStatus) {
        val currentList = _posts.value.toMutableList()
        val index = currentList.indexOfFirst { it.id == postId }
        if (index != -1) {
            currentList[index] = currentList[index].copy(status = status)
            _posts.value = currentList
        }
    }

    fun submitClaim(
        postId: String,
        itemTitle: String,
        claimantName: String,
        claimantId: String,
        proof: String,
        preferredChannel: String
    ): UserClaim {
        val claim = UserClaim(
            id = "claim-${System.currentTimeMillis()}",
            postId = postId,
            itemTitle = itemTitle,
            claimantName = claimantName,
            claimantId = claimantId,
            proof = proof,
            preferredChannel = preferredChannel,
            status = "Under Verification"
        )
        _userClaims.value = listOf(claim) + _userClaims.value

        // Update post status to under verification
        setPostStatus(postId, ItemStatus.UNDER_VERIFICATION)

        // Seed initial message in chat
        val nowStr = SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date())
        sendChatMessage(
            postId = postId,
            sender = "me",
            text = "[Ownership Claim Submitted] Hello, I am submitting a claim for '$itemTitle'. My Student/Staff ID: $claimantId. Proof details: $proof",
            time = nowStr
        )
        sendChatMessage(
            postId = postId,
            sender = "them",
            text = "Thank you for the verification details. I will review your proof and coordinate with Campus Security for the return handoff.",
            time = nowStr
        )

        return claim
    }

    fun sendChatMessage(postId: String, sender: String, text: String, time: String) {
        val currentMap = _chatHistories.value.toMutableMap()
        val list = currentMap[postId]?.toMutableList() ?: mutableListOf()
        list.add(
            ChatMessage(
                id = "msg-${System.currentTimeMillis()}-${(0..999).random()}",
                sender = sender,
                text = text,
                time = time
            )
        )
        currentMap[postId] = list
        _chatHistories.value = currentMap
    }

    private fun getInitialPosts(): List<ItemPost> {
        val now = System.currentTimeMillis()
        return listOf(
            ItemPost(
                id = "post-2",
                type = PostType.LOST,
                title = "Apple AirPods Pro in Matte Gray Case",
                category = "Electronics",
                location = "Central Library",
                locationDetail = "Second floor quiet study cubicle #14",
                dateDisplay = "Today, 09:15 AM",
                timestamp = now - 3600000 * 4,
                status = ItemStatus.ACTIVE,
                description = "Case has a small silver anime sticker on back and a tiny scratch on right bud stem. Reward offered to whoever returns it!",
                contactPref = "In-App Chat",
                author = "Devang Sharma",
                authorRole = "Student",
                avatarInitials = "DS",
                iconType = "airpods"
            ),
            ItemPost(
                id = "post-4",
                type = PostType.LOST,
                title = "HP 65W USB-C Laptop Charger",
                category = "Electronics",
                location = "Main Auditorium",
                locationDetail = "Row H, Seat 12 during TechFest briefing",
                dateDisplay = "Yesterday, 02:00 PM",
                timestamp = now - 3600000 * 26,
                status = ItemStatus.ACTIVE,
                description = "Black power brick with coiled cable. Has yellow tape mark around the adapter cord.",
                contactPref = "In-App Chat",
                author = "Meera Rao",
                authorRole = "Student",
                avatarInitials = "MR",
                iconType = "charger"
            ),
            ItemPost(
                id = "post-6",
                type = PostType.LOST,
                title = "Scientific Calculator Casio fx-991EX",
                category = "Electronics",
                location = "Building A Canteen",
                locationDetail = "Juice bar wooden bench",
                dateDisplay = "3 Days ago",
                timestamp = now - 3600000 * 70,
                status = ItemStatus.RESOLVED,
                description = "White slide-on cover with initial \"NP\" etched on top left corner.",
                contactPref = "In-App Chat",
                author = "Nikhil Patel",
                authorRole = "Student",
                avatarInitials = "NP",
                iconType = "calculator"
            ),
            ItemPost(
                id = "post-1",
                type = PostType.FOUND,
                title = "Student ID Card (B.Tech CSE - 3rd Year)",
                category = "ID Cards/Documents",
                location = "Building A Canteen",
                locationDetail = "Table near Nescafe counter",
                dateDisplay = "Today, 11:30 AM",
                timestamp = now - 3600000 * 2,
                status = ItemStatus.ACTIVE,
                description = "Found blue lanyard student identity card belonging to Harshil Mehta (Enrollment: 92100103...). Deposited at cafeteria counter manager.",
                contactPref = "Security Desk",
                author = "Pooja V.",
                authorRole = "Faculty",
                avatarInitials = "PV",
                iconType = "id-card"
            ),
            ItemPost(
                id = "post-3",
                type = PostType.FOUND,
                title = "Hyundai Car Key with Red Leather Tag",
                category = "Keys",
                location = "Bus & Visitor Parking",
                locationDetail = "Paved walkway near Gate 2 bus shelter",
                dateDisplay = "Yesterday, 04:45 PM",
                timestamp = now - 3600000 * 24,
                status = ItemStatus.UNDER_VERIFICATION,
                description = "Electronic remote fob with a red woven keychain and small silver ring. Kept securely with Main Security Gate 2 officer.",
                contactPref = "Security Desk",
                author = "Campus Guard Ramesh",
                authorRole = "Staff",
                avatarInitials = "RG",
                iconType = "key"
            ),
            ItemPost(
                id = "post-5",
                type = PostType.FOUND,
                title = "Wildcraft Black & Teal Backpack",
                category = "Bags",
                location = "PG Hostel Block B",
                locationDetail = "Lobby sofa near Table Tennis room",
                dateDisplay = "2 Days ago",
                timestamp = now - 3600000 * 48,
                status = ItemStatus.CLAIMED,
                description = "Contains Engineering Mathematics spiral notebook and a blue metal water bottle. Name on notebook reads K. Trivedi.",
                contactPref = "In-App Chat",
                author = "Hostel Warden Office",
                authorRole = "Staff",
                avatarInitials = "HW",
                iconType = "backpack"
            ),
            ItemPost(
                id = "post-7",
                type = PostType.FOUND,
                title = "Prescription Glasses (Brown Tortoise Frame)",
                category = "Others",
                location = "Central Library",
                locationDetail = "Ground floor newspaper stand",
                dateDisplay = "Today, 01:10 PM",
                timestamp = now - 3600000 * 1,
                status = ItemStatus.ACTIVE,
                description = "Reading glasses in an amber translucent hard case. Ray-Ban branded frame.",
                contactPref = "In-App Chat",
                author = "Library Staff (Rekha B.)",
                authorRole = "Staff",
                avatarInitials = "RB",
                iconType = "glasses"
            )
        )
    }

    private fun getInitialClaims(): List<UserClaim> {
        return listOf(
            UserClaim(
                id = "claim-seed-1",
                postId = "post-3",
                itemTitle = "Hyundai Car Key with Red Leather Tag",
                claimantName = "Aarav Patel",
                claimantId = "MU2022CS089",
                proof = "There is a small circular brass temple token on the same ring and a scratch near the lock button.",
                preferredChannel = "Security Gate Verification",
                status = "Pending Verification by Guard Ramesh",
                timestamp = System.currentTimeMillis() - 3600000 * 12
            )
        )
    }

    private fun getInitialChatHistories(): Map<String, List<ChatMessage>> {
        return mapOf(
            "post-1" to listOf(
                ChatMessage("1", "them", "Hello! I found this ID card near the Nescafe counter.", "11:40 AM"),
                ChatMessage("2", "me", "Hi, I think this belongs to my classmate Harshil.", "11:42 AM"),
                ChatMessage("3", "them", "Great, he can pick it up at the cafeteria counter manager!", "11:45 AM")
            ),
            "post-2" to listOf(
                ChatMessage("1", "them", "Thanks for noticing the post. Where did you last see the case?", "09:30 AM"),
                ChatMessage("2", "me", "I think on table #14 in Central Library second floor around 9 AM.", "09:35 AM")
            ),
            "post-3" to listOf(
                ChatMessage("1", "them", "Guard Ramesh here. Please bring your registration card or spare key to Gate 1.", "05:00 PM")
            ),
            "post-4" to listOf(
                ChatMessage("1", "them", "Hi, did anyone notice this in the Auditorium?", "Yesterday")
            )
        )
    }
}
